/*
 * motor_Controller.c
 *
 *  Created on: Jul 10, 2025
 *      Author: dl1wj
 */


#include "main.h"

extern TIM_HandleTypeDef htim4;

void motor_forward( uint16_t speed){



		HAL_GPIO_WritePin(PA11_MOTOR_IN3_GPIO_Port, PA11_MOTOR_IN3_Pin, 1);
		HAL_GPIO_WritePin(PA12_MOTOR_IN4_GPIO_Port, PA12_MOTOR_IN4_Pin, 0);
		//PB9
		__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_4, speed);
}

void motor_backward(uint16_t speed)
{

			HAL_GPIO_WritePin(PA11_MOTOR_IN3_GPIO_Port, PA11_MOTOR_IN3_Pin, 0);
			HAL_GPIO_WritePin(PA12_MOTOR_IN4_GPIO_Port, PA12_MOTOR_IN4_Pin, 1);

			__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_4, speed);

}

void motor_stop(void)
{

	HAL_GPIO_WritePin(PA11_MOTOR_IN3_GPIO_Port, PA11_MOTOR_IN3_Pin, 0);
	HAL_GPIO_WritePin(PA12_MOTOR_IN4_GPIO_Port, PA12_MOTOR_IN4_Pin, 0);

	__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_4, 0);
}

void servo_set_pulse(uint16_t pulse)
{
  // TIM2의 채널3 Pulse 값을 설정
  __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_3, pulse);
}

