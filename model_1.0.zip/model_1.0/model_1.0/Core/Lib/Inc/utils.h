#ifndef __UTILS_H__
#define __UTILS_H__

#include "main.h"

int _write(int file,char * p, int len);

extern UART_HandleTypeDef huart1;

#endif
