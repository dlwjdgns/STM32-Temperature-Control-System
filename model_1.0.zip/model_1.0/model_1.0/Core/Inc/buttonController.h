#ifndef _BUTTON_CONTROLLER_H_
#define _BUTTON_CONTROLLER_H_

#include "ex_var.h"
#include "main.h"
#include "controlType.h"

void checkButton();
ON_OFF_t getSwState();


#endif
