#ifndef _G_VAR_H_
#define _G_VAR_H_


extern char g_f_sw_up;
extern char g_f_sw_down;
extern char g_f_sw_fix;
extern char g_f_sw_on;

#endif
