/*
 * controlType.h
 *
 *  Created on: Jul 13, 2022
 *      Author: JiWanOh
 */

#ifndef INC_CONTROLTYPE_H_
#define INC_CONTROLTYPE_H_

typedef enum{
	OFF_t = 0,
	ON_t = 1
}ON_OFF_t;



#endif /* INC_CONTROLTYPE_H_ */
