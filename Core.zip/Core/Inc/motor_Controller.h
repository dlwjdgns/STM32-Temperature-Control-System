/*
 * motor_Controller.h
 *
 *  Created on: Jul 10, 2025
 *      Author: dl1wj
 */

#ifndef INC_MOTOR_CONTROLLER_H_
#define INC_MOTOR_CONTROLLER_H_

void motor_forward(uint8_t motor_Select, uint16_t speed);
void motor_backward(uint8_t motor_Select, uint16_t speed);
void motor_stop(void);
void servo_set_pulse(uint16_t pulse);

#endif /* INC_MOTOR_CONTROLLER_H_ */
