#ifndef _G_VAR_H_
#define _G_VAR_H_


char g_f_sw_up =0;
char g_f_sw_down=0;
char g_f_sw_fix=0;
char g_f_sw_on=0;
#endif
